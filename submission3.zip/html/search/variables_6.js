var searchData=
[
  ['jenis_5fmakanan',['jenis_makanan',['../class_animal.html#a703d6acefaa69242f9665c81f3e91c21',1,'Animal']]],
  ['jumlahanimal',['JumlahAnimal',['../class_cage.html#a4e04166edf60c708910a7b1c6d81bf3a',1,'Cage']]]
];
