var searchData=
[
  ['size_5fx',['size_x',['../class_cell.html#af80d7dad162978ba5aa1ff3fca5f632e',1,'Cell']]],
  ['size_5fy',['size_y',['../class_cell.html#a9d3a8fb3bdc4e5424e096230a62651e1',1,'Cell']]],
  ['sizecage',['SizeCage',['../class_cell.html#a21f64b557520adc51e3182516a4e2b39',1,'Cell']]],
  ['species',['species',['../class_animal.html#a70a223fc101b56962088b16a8b18534b',1,'Animal']]]
];
