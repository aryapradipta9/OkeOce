var searchData=
[
  ['masuk',['Masuk',['../class_cell.html#a75f27b85e6ce241c3cf231a020ffd95b',1,'Cell']]]
];
