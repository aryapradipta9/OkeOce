var searchData=
[
  ['ursoidea',['Ursoidea',['../class_ursoidea.html',1,'']]]
];
