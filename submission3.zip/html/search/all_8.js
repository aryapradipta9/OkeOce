var searchData=
[
  ['indianpython',['IndianPython',['../class_indian_python.html',1,'IndianPython'],['../class_indian_python.html#a2384f82da43f7ccd9cf19bfacc7bc280',1,'IndianPython::IndianPython()']]],
  ['iscomplete',['IsComplete',['../class_cell.html#a04ab2d9a4c5762aed152d95e87e0cb66',1,'Cell']]],
  ['ishabitat',['IsHabitat',['../class_habitat.html#a94e5f56b954f701e6a37007951ff9b62',1,'Habitat::IsHabitat()'],['../class_point.html#a3f1c658377b38bc7b05eea32dab203fb',1,'Point::IsHabitat()']]],
  ['isjalan',['IsJalan',['../class_point.html#a09d84d2aa58ff1257e4c08ff472c6530',1,'Point::IsJalan()'],['../class_road.html#a0363fc19374b8fa525ee66a3eb255258',1,'Road::IsJalan()']]]
];
