var searchData=
[
  ['berat',['berat',['../class_animal.html#ad122855148e51ecfe706d099bb0eb6ac',1,'Animal']]]
];
