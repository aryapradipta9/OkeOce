var searchData=
[
  ['y',['y',['../class_point.html#a2e1b5fb2b2a83571f5c0bc0f66a73cf7',1,'Point']]]
];
