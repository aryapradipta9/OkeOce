var searchData=
[
  ['famili',['famili',['../class_animal.html#aab17c94dd15ad3224c3c05ac74367be9',1,'Animal']]]
];
