var searchData=
[
  ['top_5fenemy',['top_enemy',['../class_animal.html#a6620fb4081b171927278a00638d8d2d9',1,'Animal']]],
  ['topcage',['TopCage',['../class_cell.html#a07fcbd02fd8a0363a9c0166a2df62e4c',1,'Cell']]],
  ['type',['type',['../class_animal.html#a0f113636c4f0a8ad73b1eba947a2e8e2',1,'Animal']]]
];
