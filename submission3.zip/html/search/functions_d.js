var searchData=
[
  ['okapi',['Okapi',['../class_okapi.html#a9920604ed4f8facf8b3ce4e1cbf59995',1,'Okapi']]],
  ['omnivora',['Omnivora',['../class_omnivora.html#a5073dcd66e4ebe988dffbafd2bb9b745',1,'Omnivora']]],
  ['operator_3d',['operator=',['../class_cell.html#a42eb7226a9c960006f78f73d6a04f091',1,'Cell']]],
  ['orangutan',['Orangutan',['../class_orangutan.html#a2da89098271e7e34a0e81e3dc8d732f5',1,'Orangutan']]]
];
