var searchData=
[
  ['habitat_5ftype',['habitat_type',['../class_habitat.html#aa2d593697c3e7c1c0c52b3804c019e01',1,'Habitat']]],
  ['habtype',['HabType',['../class_cage.html#a84ab0098eebdb6ce6d00a64533eb963c',1,'Cage']]]
];
