var searchData=
[
  ['jenis_5fmakanan',['jenis_makanan',['../class_animal.html#a703d6acefaa69242f9665c81f3e91c21',1,'Animal']]],
  ['jumlahanimal',['JumlahAnimal',['../class_cage.html#a4e04166edf60c708910a7b1c6d81bf3a',1,'Cage']]],
  ['jumlahmakancell',['JumlahMakanCell',['../class_cell.html#ad1c6c85484bcc0a3d833fc2584d6e12d',1,'Cell']]],
  ['jumlahmakankandang',['JumlahMakanKandang',['../class_cage.html#a4aaadecb8628c82e3611cc3bf99df9b3',1,'Cage']]]
];
