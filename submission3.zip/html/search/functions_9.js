var searchData=
[
  ['jumlahmakancell',['JumlahMakanCell',['../class_cell.html#ad1c6c85484bcc0a3d833fc2584d6e12d',1,'Cell']]],
  ['jumlahmakankandang',['JumlahMakanKandang',['../class_cage.html#a4aaadecb8628c82e3611cc3bf99df9b3',1,'Cage']]]
];
