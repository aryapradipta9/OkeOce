var searchData=
[
  ['ursoidea',['Ursoidea',['../class_ursoidea.html#a29e3319ed126f6b46f014696df2d90a0',1,'Ursoidea']]]
];
