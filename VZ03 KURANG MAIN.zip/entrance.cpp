#include "entrance.h"

/**	@brief Jalan masuk
  *	@param pos_x posisi x
  *	@param pos_y posisi y
  */
Entrance::Entrance(int pos_x, int pos_y) : Road(pos_x,pos_y) {}
