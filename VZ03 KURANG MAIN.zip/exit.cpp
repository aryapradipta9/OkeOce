#include "exit.h"

/** @brief Jalan keluar
  * @param pos_x posisi x
  * @param pos_y posisi y
  */
Exit::Exit(int pos_x, int pos_y) : Road(pos_x,pos_y) {}
