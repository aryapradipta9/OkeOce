#ifndef LAND_ANIMAL_H
#define LAND_ANIMAL_H
#include "animal.h"

class LandAnimal : virtual public Animal {
public:
	/** @brief Inisialisasi Tipe Animal
	  */
	LandAnimal();
};
#endif
