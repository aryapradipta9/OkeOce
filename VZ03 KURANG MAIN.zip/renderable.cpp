#include "renderable.h"

  /** @brief Kelas virtual render
    * @param cc matriks yang akan diprint
    */
void Renderable::Render(char** cc) {}
