#include "interface.h"
#include "boolean.h"
#include <stdio.h>

Player P;

int main()
{
  boolean game_start, game_end;
  main_menu(&game_start, &game_end);
  boolean player_lose = false;
  while ((game_start) && (!player_lose))
  {
    mapdraw();
    // kalau ketemu musuh, init_battle diisi true. kalau musuh
  }
  return 0;
}
