/* NIM/Nama : 13515017 / Putu Arya Pradipta */
/* Kelompok : 9 */
/* Deskripsi: Implementasi ADT interface (interface.c) */

#include <stdio.h>
#include <unistd.h>
#include "tree.h"
#include "boolean.h"
#include "addadt.h"
#include "matriks.h"
#include "interface.h"

#define clearScreen() printf("\033[H\033[J")
#define clearRow() printf("\33[2K")
#define gotoxy(x,y) printf("\033[%d;%dH", (x), (y))

// library warna
#define RED   "\x1B[31m"
#define GRN   "\x1B[32m"
#define YEL   "\x1B[33m"
#define BLU   "\x1B[34m"
#define MAG   "\x1B[35m"
#define CYN   "\x1B[36m"
#define WHT   "\x1B[37m"
#define RESET "\x1B[0m"

Player P;

int mapinterface(int depth)
{
  clearScreen();
  printf(BLU);
  printf("╔═══════════════════════╦══════════╦══════════╦══════════╦══════════╦═════════════════════════╗\n");
  printf("║                       ║          ║          ║          ║          ║                         ║\n");
  printf("╠═══════════════════════╩══════════╩══════════╩══════════╩══════════╩═════════════════════════╣\n");
  int i;
  for (i = 1; i <= depth; i++)
  {printf("║                                                                                             ║\n");}
  printf("╠═════════════════════════════════════════════════════════════════════════════════════════════╣\n");
  printf("║                                                                                             ║\n");
  printf("╠═════════════════════════════════════════════════════════════════════════════════════════════╣\n");
  printf("║                                                                                             ║\n");
  printf("╚═════════════════════════════════════════════════════════════════════════════════════════════╝\n");
  printf(RESET);
  gotoxy(2,3);
  printf("%s",P.Nama);
  gotoxy(2,27);
  printf("LVL : %d",P.LVL);
  gotoxy(2,38);
  printf("HP : %d",P.HP);
  gotoxy(2,49);
  printf("STR : %d",P.STR);
  gotoxy(2,60);
  printf("DEF : %d",P.DEF);
  gotoxy(2,71);
  printf("EXP : %d/%d",P.EXP,P.NextLVL);
}

int treebuilder (BinTree *T)
{
  MakeTree(T);
  int BaseXPoint, BaseYPoint, PrevBaseYPoint, DivBaseYPoint, SecondBaseYPoint;
  BaseXPoint = 5;
  BaseYPoint = 47;
  gotoxy(BaseXPoint,BaseYPoint-2); printf("╔═══╗");
  gotoxy(BaseXPoint + 1,BaseYPoint-2); printf("║   ║");
  gotoxy(BaseXPoint + 2,BaseYPoint-2); printf("╚═══╝");
  gotoxy(BaseXPoint+ 3,BaseYPoint); printf("┃");
  gotoxy(BaseXPoint+ 4,BaseYPoint / 2); printf("┏━━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━┓");
  gotoxy(BaseXPoint + 1,BaseYPoint);
  Akar(*T).PosX = BaseXPoint + 1;
  Akar(*T).PosY = BaseYPoint;
  if (Akar(*T).taken == true)
  {
    printf(RED "%c" RESET,Akar(*T).cc);
  }
  else
  {
    printf("%c",Akar(*T).cc);
  }


  // print kedua --> ganti base jadi x+6,y div 2
  PrevBaseYPoint = BaseYPoint;
  BaseXPoint = BaseXPoint + 6;
  BaseYPoint = BaseYPoint / 2;
  DivBaseYPoint = BaseYPoint / 2;
  int i;
  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,BaseYPoint); printf("┃");
    gotoxy(BaseXPoint,BaseYPoint-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,BaseYPoint-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,BaseYPoint-2); printf("╚═══╝");
    gotoxy(BaseXPoint+ 3,BaseYPoint); printf("┃");
    gotoxy(BaseXPoint+ 4,BaseYPoint - DivBaseYPoint - 1); printf("┏━━━━━━━━━━━┻━━━━━━━━━━━┓");
    gotoxy(BaseXPoint + 1,BaseYPoint );

    if (i == 1)
    {
      Akar(Left(*T)).PosX = BaseXPoint + 1;
      Akar(Left(*T)).PosY = BaseYPoint;
      if (Akar(Left(*T)).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(*T)).cc);
      }
      else
      {
        printf("%c",Akar(Left(*T)).cc);
      }
    }
    else
    {
      Akar(Right(*T)).PosX = BaseXPoint + 1;
      Akar(Right(*T)).PosY = BaseYPoint;
      if (Akar(Right(*T)).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(*T)).cc);
      }
      else
      {
        printf("%c",Akar(Right(*T)).cc);
      }
    }
    if (i == 1) {BaseYPoint = BaseYPoint + PrevBaseYPoint + 1;}
  }

  int res;
  res = BaseYPoint;
  //kembalikan BaseYPoint
  BaseYPoint = (BaseYPoint - 1 - PrevBaseYPoint);
  //buat level 3 untuk cabang pertama
  PrevBaseYPoint = BaseYPoint;
  BaseXPoint = BaseXPoint + 6;
  BaseYPoint = BaseYPoint / 2;
  res = res - BaseYPoint - 1;
  DivBaseYPoint = BaseYPoint / 2;
  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,BaseYPoint); printf("┃");
    gotoxy(BaseXPoint,BaseYPoint-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,BaseYPoint-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,BaseYPoint-2); printf("╚═══╝");
    gotoxy(BaseXPoint+ 3,BaseYPoint); printf("┃");
    gotoxy(BaseXPoint+ 4,BaseYPoint - DivBaseYPoint - 1); printf("┏━━━━━┻━━━━━┓");
    gotoxy(BaseXPoint + 1,BaseYPoint );
    if (i == 1)
    {
      Akar(Left(Left(*T))).PosX = BaseXPoint + 1;
      Akar(Left(Left(*T))).PosY = BaseYPoint;
      if (Akar(Left(Left(*T))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(Left(*T))).cc);
      }
      else
      {
        printf("%c",Akar(Left(Left(*T))).cc);
      }
    }
    else
    {
      Akar(Right(Left(*T))).PosX = BaseXPoint + 1;
      Akar(Right(Left(*T))).PosY = BaseYPoint;
      if (Akar(Right(Left(*T))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(Left(*T))).cc);
      }
      else
      {
        printf("%c",Akar(Right(Left(*T))).cc);
      }
    }
    if (i == 1) {BaseYPoint = BaseYPoint + PrevBaseYPoint + 1;}
  }

  // buat reserve untuk BaseYPoint
  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,res); printf("┃");
    gotoxy(BaseXPoint,res-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,res-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,res-2); printf("╚═══╝");
    gotoxy(BaseXPoint+ 3,res); printf("┃");
    gotoxy(BaseXPoint+ 4,res - DivBaseYPoint - 1); printf("┏━━━━━┻━━━━━┓");
    gotoxy(BaseXPoint + 1,res );
    if (i == 1)
    {
      Akar(Left(Right(*T))).PosX = BaseXPoint + 1;
      Akar(Left(Right(*T))).PosY = res;
      if (Akar(Left(Right(*T))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(Right(*T))).cc);
      }
      else
      {
        printf("%c",Akar(Left(Right(*T))).cc);
      }
    }
    else
    {
      Akar(Right(Right(*T))).PosX = BaseXPoint + 1;
      Akar(Right(Right(*T))).PosY = res;
      if (Akar(Right(Right(*T))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(Right(*T))).cc);
      }
      else
      {
        printf("%c",Akar(Right(Right(*T))).cc);
      }
    }
    if (i == 1) {res = res + PrevBaseYPoint + 1;}
  }
  // kembalikan res
  int res2;
  res2 = res;
  res = res - PrevBaseYPoint - 1;
  SecondBaseYPoint = BaseYPoint - DivBaseYPoint - 1;


  //kembalikan BaseYPoint
  BaseYPoint = (BaseYPoint - 1 - PrevBaseYPoint);
  // buat level 4 untuk cabang pertamanya
  PrevBaseYPoint = BaseYPoint;
  BaseXPoint = BaseXPoint + 6;
  BaseYPoint = BaseYPoint / 2;
  res = res - BaseYPoint - 1;
  res2 = res2 - BaseYPoint - 1;
  DivBaseYPoint = BaseYPoint / 2;
  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,BaseYPoint); printf("┃");
    gotoxy(BaseXPoint,BaseYPoint-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,BaseYPoint-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,BaseYPoint-2); printf("╚═══╝");
    gotoxy(BaseXPoint + 1,BaseYPoint );
    if (i == 1)
    {
      Akar(Left(Left(Left(*T)))).PosX = BaseXPoint + 1;
      Akar(Left(Left(Left(*T)))).PosY = BaseYPoint;
      if (Akar(Left(Left(Left(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(Left(Left(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Left(Left(Left(*T)))).cc);
      }
    }
    else
    {
      Akar(Right(Left(Left(*T)))).PosX = BaseXPoint + 1;
      Akar(Right(Left(Left(*T)))).PosY = BaseYPoint;
      if (Akar(Right(Left(Left(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(Left(Left(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Right(Left(Left(*T)))).cc);
      }
    }
    if (i == 1) {BaseYPoint = BaseYPoint + PrevBaseYPoint + 1;}
  }

  // buat level 4 untuk cabang kedua
  // BaseXPoint sama dengan sebelumnya
  BaseYPoint = SecondBaseYPoint;
  // DivBaseYPoint sama dengan sebelumnya;
  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,BaseYPoint); printf("┃");
    gotoxy(BaseXPoint,BaseYPoint-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,BaseYPoint-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,BaseYPoint-2); printf("╚═══╝");
    gotoxy(BaseXPoint + 1,BaseYPoint );
    if (i == 1)
    {
      Akar(Left(Right(Left(*T)))).PosX = BaseXPoint + 1;
      Akar(Left(Right(Left(*T)))).PosY = BaseYPoint;
      if (Akar(Left(Right(Left(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(Right(Left(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Left(Right(Left(*T)))).cc);
      }
    }
    else
    {
      Akar(Right(Right(Left(*T)))).PosX = BaseXPoint + 1;
      Akar(Right(Right(Left(*T)))).PosY = BaseYPoint;
      if (Akar(Right(Right(Left(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(Right(Left(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Right(Right(Left(*T)))).cc);
      }
    }
    if (i == 1) {BaseYPoint = BaseYPoint + PrevBaseYPoint + 1;}
  }

  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,res); printf("┃");
    gotoxy(BaseXPoint,res-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,res-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,res-2); printf("╚═══╝");
    gotoxy(BaseXPoint + 1,res );
    if (i == 1)
    {
      Akar(Left(Left(Right(*T)))).PosX = BaseXPoint + 1;
      Akar(Left(Left(Right(*T)))).PosY = res;
      if (Akar(Left(Left(Right(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(Left(Right(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Left(Left(Right(*T)))).cc);
      }
    }
    else
    {
      Akar(Right(Left(Right(*T)))).PosX = BaseXPoint + 1;
      Akar(Right(Left(Right(*T)))).PosY = res;
      if (Akar(Right(Left(Right(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(Left(Right(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Right(Left(Right(*T)))).cc);
      }
    }
    if (i == 1) {res = res + PrevBaseYPoint + 1;}
  }

  for (i = 1; i <= 2; i++)
  {
    gotoxy(BaseXPoint-1,res2); printf("┃");
    gotoxy(BaseXPoint,res2-2); printf("╔═══╗");
    gotoxy(BaseXPoint + 1,res2-2); printf("║   ║");
    gotoxy(BaseXPoint + 2,res2-2); printf("╚═══╝");
    gotoxy(BaseXPoint + 1,res2 );
    if (i == 1)
    {
      Akar(Left(Right(Right(*T)))).PosX = BaseXPoint + 1;
      Akar(Left(Right(Right(*T)))).PosY = res2;
      if (Akar(Left(Right(Right(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Left(Right(Right(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Left(Right(Right(*T)))).cc);
      }
    }
    else
    {
      Akar(Right(Right(Right(*T)))).PosX = BaseXPoint + 1;
      Akar(Right(Right(Right(*T)))).PosY = res2;
      if (Akar(Right(Right(Right(*T)))).taken == true)
      {
        printf(RED "%c" RESET,Akar(Right(Right(Right(*T)))).cc);
      }
      else
      {
        printf("%c",Akar(Right(Right(Right(*T)))).cc);
      }
    }
    if (i == 1) {res2 = res2 + PrevBaseYPoint + 1;}
  }
  return 0;
}


int enemyloading ()
{
  // entry string
  const char *interface[15];
  interface[0] = "888888b.           d8b          888      888                               888";
  interface[1] = "888  '88b          Y8P          888      888                               888";
  interface[2] = "888  .88P                       888      888                               888";
  interface[3] = "8888888K.  888d888 888  .d88b.  88888b.  888888 .d8888b   .d88b.  888  888 888 .d8888b";
  interface[4] = "888  'Y88b 888P'   888 d88P'88b 888 '88b 888    88K      d88''88b 888  888 888 88K";
  interface[5] = "888    888 888     888 888  888 888  888 888    'Y8888b. 888  888 888  888 888 'Y8888b.";
  interface[6] = "888   d88P 888     888 Y88b 888 888  888 Y88b.       X88 Y88..88P Y88b 888 888      X88";
  interface[7] = "8888888P'  888     888  'Y88888 888  888  'Y888  88888P'  'Y88P'   'Y88888 888  88888P'";
  interface[8] = "                            888";
  interface[9] = "                       Y8b d88P";
  interface[10] = "                        'Y88P'";
  interface[11] = "╔══════════════════════════════╗";
  interface[13] = "╚══════════════════════════════╝";
  interface[12] = "An Enemy is Approaching";
  int i, j,k;
  for (k =0; k<=3; k++)
  {
    for (j=0; j<=10; j++)
    {
      clearScreen();
      for (i=0; i<= 10; i++)
      {
        if (j == i)
        {
          printf(RED "%s\n" RESET, interface[i]);
        }
        else
        {
          printf("%s\n", interface[i]);
        }
      }
      printf("\n\n%s\n",interface[11]);
      if ((j % 2) == 0)
      {
        printf("║    " RED "%s" RESET "   ║\n",interface[12]);
      }
      else
      {
        printf("║    %s   ║\n",interface[12]);
      }
      printf("%s\n",interface[13]);
      usleep(100000);
    }
  }


return 0;
}

void main_menu(boolean * game_start, boolean * game_end)
{
  const char *interface[20];
  interface[0] = "888888b.           d8b          888      888                               888";
  interface[1] = "888  '88b          Y8P          888      888                               888";
  interface[2] = "888  .88P                       888      888                               888";
  interface[3] = "8888888K.  888d888 888  .d88b.  88888b.  888888 .d8888b   .d88b.  888  888 888 .d8888b";
  interface[4] = "888  'Y88b 888P'   888 d88P'88b 888 '88b 888    88K      d88''88b 888  888 888 88K";
  interface[5] = "888    888 888     888 888  888 888  888 888    'Y8888b. 888  888 888  888 888 'Y8888b.";
  interface[6] = "888   d88P 888     888 Y88b 888 888  888 Y88b.       X88 Y88..88P Y88b 888 888      X88";
  interface[7] = "8888888P'  888     888  'Y88888 888  888  'Y888  88888P'  'Y88P'   'Y88888 888  88888P'";
  interface[8] = "                            888";
  interface[9] = "                       Y8b d88P";
  interface[10] = "                        'Y88P'";
  interface[11] = "                         ╔══════════════════════════════╗";
  interface[12] = "                         ║                              ║";
  interface[13] = "                         ╚══════════════════════════════╝";
  interface[14] = "Welcome, ";
  interface[15] = "You haven't create your profile yet.";
  interface[16] = "New Game";
  interface[17] = "Start Game";
  interface[18] = "Load Game";
  interface[19] = "Quit Game";

  int i,j,k;
  for (j=0; j<=11; j++)
  {
    clearScreen();
    for (i=0; i<= 10; i++)
    {
      if (j == i)
      {
        printf(RED "%s\n" RESET, interface[i]);
      }
      else
      {
        printf("%s\n", interface[i]);
      }
    }
    usleep(100000);
  }

  char player_name[20];
  char cc;
  boolean load_profile = false;
  *game_start = false;
  *game_end = false;
  // start index = 15
  while ((!(*game_start)) && (!(*game_end)))
  {
    for (i=15; i<=22; i++)
    {
      gotoxy(i,1);
      clearRow();
    }
    gotoxy(15,1);
    printf("%s\n",interface[11]);
    for (i=14; i<=19; i++)
    {
      gotoxy(i+2,1);
      printf("%s",interface[12]);
    }
    gotoxy(i+2,1);
    printf("%s",interface[13]);
    gotoxy(16,29);
    if (load_profile)
    {
      AniPrintConst("Welcome, ");
      AniPrint(player_name);
      printf("\n");
    }
    else
    {
      AniPrintConst("Welcome, ");
      printf("\n");
    }
    for (i=16; i<=19; i++)
    {
      gotoxy(i+2,29);
      AniPrintConst(interface[i]);
    }

    // kursor
    int PosX = 18;
    gotoxy(18,28);
    printf(">");
    gotoxy(18,28);
    // cleaning
    while (cc == 'E')
    {
      cc = ArrowPressed();
    }
    while(cc != 'E')
    {
      if ((cc == 'u') && (PosX > 18))
      {
        gotoxy(PosX,28);
        printf(" ");
        PosX--;
        gotoxy(PosX,28);
        printf(">");
        gotoxy(PosX,28);
      }
      else if ((cc == 'd') && (PosX < 21))
      {
        gotoxy(PosX,28);
        printf(" ");
        PosX++;
        gotoxy(PosX,28);
        printf(">");
        gotoxy(PosX,28);
      }
      cc = ArrowPressed();
    }
    // clearing border
    for (i=15; i<=22; i++)
    {
      gotoxy(i,1);
      clearRow();
    }
    gotoxy(15,1);
    printf("%s\n",interface[11]);
    if (PosX == 18)
    {
      for(i=16;i<=19;i++)
      {
        printf("%s\n",interface[12]);
      }
      printf("%s",interface[13]);
      gotoxy(16,28);
      printf("Please enter your username : ");
      gotoxy(18,28);
      scanf(" %s",player_name);
      // penulisan state
      load_profile = true;
    }
    else if (PosX == 19)
    {
      if (load_profile)
      {
        // start game
        CopyString(P.Nama,player_name);
        P.STR = 10;
        P.DEF = 10;
        P.EXP = 10;
        P.LVL = 1;
        P.NextLVL = 100;
        P.HP = 100;
        *game_start = true;
      }
    }
    else if (PosX == 20)
    {
      //load game
    }
    else if (PosX == 21)
    {
      *game_end = true;
      credits();
    }
  }
}

int mapdraw ()
{
  mapinterface(33);
  MATRIKS M;
  int i, j;
  for (i = 1; i <= 11; i++)
  {
    if (i == 1)
    {
      gotoxy(10,22);
      printf(CYN "┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐" RESET);
    }
    gotoxy(11+2*(i-1),22);
    printf(CYN "│" RESET);
    for (j = 1; j <= 11; j++)
    {
      printf(" %c " CYN "│" RESET ,Elmt(M,i,j));
    }
    gotoxy(12+2*(i-1),22);
    if (i == 11)
    {printf(CYN "└───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘" RESET);}
    else {printf(CYN "├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤" RESET);}
  }
  gotoxy(38,3);
  printf("Please input your command!");
  gotoxy(40,3);
  printf("Command : ");
  return 0;
}

void battle_interface ( Enemy E, int Ronde)
{
  printf(CYN);
  printf("╔═══════════════════════╦══════════╦══════════╦══════════╦══════════╦═════════════╗\n");
  printf("║                       ║          ║          ║          ║          ║             ║\n");
  printf("╠═══════════════════════╬══════════╬══════════╩══════════╩══════════╩═════════════╣\n");
  printf("║                       ║          ║                                              ║\n");
  printf("╠═══════════════════════╩══════════╩══════════════════════════════════════════════╣\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("║                                                                                 ║\n");
  printf("╠═══════════════════════╦═════════════════════════════════════════════════════════╣\n");
  printf("║                       ║                                                         ║\n");
  printf("╠═══════════════════════╬═════════════════════════════════════════════════════════╣\n");
  printf("║                       ║                                                         ║\n");
  printf("╚═══════════════════════╩═════════════════════════════════════════════════════════╝\n");
  printf(RESET);
  gotoxy(2,3);
  printf("%s",P.Nama);
  gotoxy(2,27);
  printf("LVL : %d",P.LVL);
  gotoxy(2,38);
  printf("HP : %d",P.HP);
  gotoxy(2,49);
  printf("STR : %d",P.STR);
  gotoxy(2,60);
  printf("DEF : %d",P.DEF);
  gotoxy(2,71);
  printf("Round : %d",Ronde);
  gotoxy(4,3);
  printf("%s",E.Nama);
  gotoxy(4,27);
  printf("HP : %d",E.HP);
  gotoxy(20,3);
  printf("Inserted Commands : ");
  gotoxy(22,3);
  printf("Command :");
}

int loading_screen ()
{
  clearScreen();
  int PosX = 5;
  gotoxy(PosX,35);
  printf("𝙻 𝚘 𝚊 𝚍 𝚒 𝚗 𝚐   𝚁 𝚎 𝚜 𝚘 𝚞 𝚛 𝚌 𝚎 𝚜 \n");
  int i, j, minload, maxload, amount;
  for (i=1; i<= 100; i++)
  {
    gotoxy(PosX+1,1);
    for (j=1;j<=i;j++)
    {
      printf(RED "■" RESET);
      usleep(1);
    }
    usleep(100000);
  }
  return 0;
}

int level_up ()
{
  char cc;
  int i,j,k, l;
  const char *interface[3];
  interface[1] = "╔══════════════════════════════╗";
  interface[2] = "╚══════════════════════════════╝";
  for (l=1;l<=3;l++)
  {
    for (k = 10; k>=(-1); k--)
    {
      clearScreen();
      for (i=0; i<=5; i++)
      {
        if (i == k)
        {
          printf(RED);
        }
        gotoxy(i+1,10);
        for (j=1; j<=(5-i); j++)
        {
          printf(" ");
        }
        printf("◢");
        for (j=1; j<=i; j++)
        {
          printf("■");
        }
        for (j=1; j<=i; j++)
        {
          printf("■");
        }
        printf("◣\n" RESET);
      }
      for(i=6; i<=10; i++)
      {
        gotoxy(i+1,10);
        if (i == k)
        {
          printf(RED "  ■■■■■■■■\n" RESET);
        }
        else
        {
          printf("  ■■■■■■■■\n");
        }

      }
      gotoxy(12,1);
      printf("%s\n",interface[1]);
      if ((k % 2) == 0)
      {
        printf("║"RED"       Leveling Up...         "RESET"║\n");
      }
      else
      {
        printf("║       Leveling Up...         ║\n");
      }
        printf("%s\n",interface[2]);
      usleep(100000);
    }
  }
  clearScreen();


  int NewHP,NewStr,NewDef,Rem;
  // entry data contoh
  CopyString(P.Nama,"Encang Iskandar");
  P.LVL = 5;
  P.HP = 100;
  P.STR = 50;
  P.DEF = 40;
  P.EXP = 0;
  P.NextLVL = 100;
  mapinterface(5);
  boolean confirm = false;
  while (!confirm)
  {
    gotoxy(5,3);
    NewHP = P.HP + 10;
    NewStr = P.STR;
    NewDef = P.DEF;
    Rem = 3;
    gotoxy(5,3);
    printf("                                                 ▲              ▲");
    gotoxy(6,3);
    printf("          New Stats :     HP     %d     Str     %d     Def     %d",NewHP,NewStr,NewDef);
    gotoxy(7,3);
    printf("                                                 ▼              ▼");
    gotoxy(10,3);
    printf("You have %d remaining point(s)",Rem);
    while (Rem != 0)
    {
      int PosX = 5;
      int PosY = 52;
      gotoxy(PosX,PosY);
      cc = ArrowPressed();
      while (cc != 'E')
      {
        if ((cc == 'u') && (PosX > 5))
        {
          PosX = 5;
        }
        else if ((cc == 'd') && (PosX < 7))
        {
          PosX = 7;
        }
        else if ((cc == 'l') && (PosY > 52))
        {
          PosY = 52;
        }
        else if ((cc == 'r') && (PosY < 67))
        {
          PosY = 67;
        }
        gotoxy(PosX,PosY);
        cc = ArrowPressed();
      }
      if ((PosX == 5) && (PosY == 52))
      {
        NewStr++;
        Rem--;
      }
      else if ((PosX == 5) && (PosY == 67))
      {
        NewDef++;
        Rem--;
      }
      else if ((PosX == 7) && (PosY == 52))
      {
        if (NewStr > P.STR)
        {
          NewStr--;
          Rem++;
        }
      }
      else if ((PosX == 7) && (PosY == 67))
      {
        if (NewDef > P.DEF)
        {
          NewDef--;
          Rem++;
        }
      }
    gotoxy(5,3);
    printf("                                                 ▲              ▲");
    gotoxy(6,3);
    printf("          New Stats :     HP     %d     Str     %d     Def     %d",NewHP,NewStr,NewDef);
    gotoxy(7,3);
    printf("                                                 ▼              ▼");
    gotoxy(10,3);
    printf("You have %d remaining point(s)",Rem);
    }
    if (Rem == 0)
    {
      gotoxy(12,3);
      printf("Confirm the changes (y/n) : ");
      cc = getchar();
      if (cc == 'n')
      {
        gotoxy(12,1);
        printf("║                                                                                             ║\n");
      }
      else
      {
        P.HP = NewHP;
        P.STR = NewStr;
        P.DEF = NewDef;
        confirm = true;
      }
    }
  }
  confirm = false;
  while (!confirm)
  {
    BinTree T;
    mapinterface(33);
    // inisialisasi state dengan s
    treebuilder(&T);
    BinTree SavedT = T;
    gotoxy(Akar(T).PosX,Akar(T).PosY);
    // cleaner cc;
    // cleaning
    cc = ArrowPressed();
    while (cc == 'E')
    {
      cc = ArrowPressed();
    }
    cc = ArrowPressed();
    while (cc != 'E')
    {
      if (cc == 'u')
      {
        if (Parent(T) != Nil)
        {
          T = Parent(T);
        }
      }
      else if (cc == 'd')
      {
        if (Left(T) != Nil)
        {
          T = Left(T);
        }
      }
      else if (cc == 'l')
      {
        SavedT = T;
        if (Parent(T) != Nil)
        {
          T = Parent(T);
          if (Left(T) != Nil)
          {
            T = Left(T);
          }
          else
          {
            T = SavedT;
          }
        }
        else
        {
          T = SavedT;
        }
      }
      else if (cc == 'r')
      {
        SavedT = T;
        if (Parent(T) != Nil)
        {
          T = Parent(T);
          if (Right(T) != Nil)
          {
            T = Right(T);
          }
          else
          {
            T = SavedT;
          }
        }
        else
        {
          T = SavedT;
        }
      }
      gotoxy(Akar(T).PosX,Akar(T).PosY);
      cc = ArrowPressed();
    }
    if (cc == 'E')
    {
      gotoxy(38,3);
      printf("%s",Akar(T).description);
      gotoxy(40,3);
      printf("Enter skill (press n to go back) = ");
      cc = getchar();
      if (cc != 'n')
      {
        boolean found;
        SetTreeTaken(&T,cc,&found);
        if (found)
        {
          confirm = true;
        }
      }
    }
  }
  return 0;
}

int credits ()
{
  clearScreen();
  int i;
  printf(GRN);
  for (i=1;i<=30;i++)
  {
    if (i <=20)
    {
      gotoxy(i,1);
      printf("############################################################\n");
    }
    if ((i > 10) && (i <= 28))
    {
      gotoxy(i-9,1);
      clearRow();
      printf("#                                                          #");
    }
    fflush(stdout);
    usleep(100000);
  }
  printf(RESET);

  // tulis credits
  gotoxy(7,27);
  AniPrintConst("Credits");
  int j = 8;
  gotoxy(j,15);
  AniPrintConst("13513014 Paulus Berliz");
  j++;
  gotoxy(j,15);
  AniPrintConst("13515017 Putu Arya Pradipta");
  j++;
  gotoxy(j,15);
  AniPrintConst("13515068 M Fathur Rahman");
  j++;
  gotoxy(j,15);
  AniPrintConst("33216013 Jasman Pardede");

  gotoxy(32,1);
  return 0;
}
