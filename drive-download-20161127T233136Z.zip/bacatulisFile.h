/** File Name 	: bacatulisFile.h
  * Author		: Jasman Pardede
  * NIM			: 33216013
  * Tanggal		: 13 September 2016
  * Deskripsi	: Membuat ADT Baca dan Tulis File
  */
  
/* ********** Definisi TYPE MATRIKS dengan indeks dan elemen integer ********** */

#ifndef READ_WRITE_FILE_H
#define READ_WRITE_FILE_H

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include "boolean.h"

#define MAX_STRING_LENGTH 1000
#define MAX_FIlE_NAME_LENGTH 50
#define MAX_STRING_PATH 500



boolean isFileNameValid(char *fileName);

boolean fileExists (const char *path, const char *base);

void saveContentFile(char *fileName, char *myContent);

void getContentFile(char *fileName, char *myContent);

boolean removeFile(char *fileName);

#endif
