/* NIM/Nama : 13515017 / Putu Arya Pradipta */
/* Kelompok : 9 */
/* Deskripsi: Header ADT tree (tree.h) */

#ifndef _TREE_H_
#define _TREE_H_
#include "boolean.h"
#define Nil NULL

/* Selektor */
#define Akar(P) (P)->info
#define Left(P) (P)->left
#define Right(P) (P)->right
#define Parent(P) (P)->parent


typedef struct {
  char cc;
  boolean taken;
  char description[50];
  int PosX;
  int PosY;
} infoTree;

typedef struct tNode *addressTree;

typedef struct tNode {
  infoTree info;
  addressTree left;
  addressTree right;
  addressTree parent;
} Node;

typedef addressTree BinTree;

void AlokasiTree (addressTree *P, infoTree X);

BinTree Tree (infoTree Akar, BinTree *L, BinTree *R);

void DealokasiTree (addressTree  P);
/* I.S. P adalah hasil alokasi, P != Nil */
/* F.S. Alamat P didealokasi, dikembalikan ke sistem */

void MakeTree(BinTree *T);

boolean IsDoubeKill (BinTree T);

boolean IsTripleKill (BinTree T);

boolean IsInstaKill (BinTree T);

boolean IsDamageReceived (BinTree T);

void SetTreeTaken (BinTree *T, char cc, boolean *found);

#endif
