/* NIM/Nama : 13515017 / Putu Arya Pradipta */
/* Kelompok : 9 */
/* Deskripsi: Header ADT interface (interface.h) */

#ifndef _INTERFACE_H_
#define _INTERFACE_H_

#include "tree.h"

typedef struct {
  char Nama[50];
  int HP;
  int STR;
  int DEF;
  int EXP;
  int LVL;
  int NextLVL;
} Player;

typedef struct {
  char Nama[50];
  int HP;
  int STR;
  int DEF;
  int EXP;
} Enemy;

extern Player P;

int mapinterface(int depth);

int treebuilder (BinTree *T);

int enemyloading ();

void main_menu();

int mapdraw ();

void battle_interface (Enemy E, int Ronde);

int loading_screen();

int level_up();

int credits ();

#endif
