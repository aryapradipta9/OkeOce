/* NIM/Nama : 13515017 / Putu Arya Pradipta */
/* Kelompok : 9 */
/* Deskripsi: Implementasi ADT others (addadt.c) */

#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>

/* reads from keypress, doesn't echo */
int getch(void)
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}

/* reads from keypress, echoes */
char ArrowPressed()
{
  int x;
  x = getch();
  if (x == 10)
  {
    return 'E';
  }
  else
  {
    getch();
    x = getch();
    if (x == 65)
    {
      return 'u';
    }
    else if (x == 66)
    {
      return 'd';
    }
    else if (x == 67)
    {
      return 'r';
    }
    else if (x == 68)
    {
      return 'l';
    }
    else
    {
      return '0';
    }
  }
}

void CopyString(char dest[], const char source[])
{
  int i = 0;
  while (1)
  {
    dest[i] = source[i];
    if (dest[i] == '\0') break;
    i++;
  }
}

void AniPrint(char src[])
{
  int i = 0;
  while (src[i] != '\0')
  {
    printf("%c",src[i]);
    fflush(stdout);
    usleep(100000);
    i++;
  }
}

void AniPrintConst(const char src[])
{
  int i = 0;
  while (src[i] != '\0')
  {
    printf("%c",src[i]);
    fflush(stdout);
    usleep(100000);
    i++;
  }
}
