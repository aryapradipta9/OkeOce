#include "area.h"
#include <stdlib.h>
#include <stdio.h>
void CreateAreaEmpty(Area *A){
	Area X;
	X = (address)malloc(sizeof(AreaNode));
	if (X != Nil){
		Kiri(X) = Nil;
		Kanan(X) = Nil;
		Bawah(X) = Nil;
		Atas(X) = Nil;
		AreaID(X) = 0;
	}
	*A = X;
}
//Mengalokasi Area di memori
void Dealokasi(Area A){
	free(A);
}
//* Mencari Titik Start dari Map
POINT StartAtas(Area A){
	int i;
	i = 1;
	while (i<=11){
		if (ElmtA(A,1,i) == '-'){
			return MakePOINT(1,i);
		}
		i++;
	}
	return MakePOINT(0,0);
}
POINT StartBawah(Area A){
	int i;
	i = 1;
	while (i<=11){
		if (ElmtA(A,11,i) == '-'){
			return MakePOINT(11,i);
		}
		i++;
	}
	return MakePOINT(0,0);
}
POINT StartKanan(Area A){
	int i;
	i = 1;
	while (i<=11){
		if (ElmtA(A,i,11) == '-'){
			return MakePOINT(i,11);
		}
		i++;
	}
	return MakePOINT(0,0);
}
POINT StartKiri (Area A){
	int i;
	i = 1;
	while (i<=11){
		if (ElmtA(A,i,1) == '-'){
			return MakePOINT(i,1);
		}
		i++;
	}
	return MakePOINT(0,0);
}

void SambungHorizontal(Area *A1,Area *A2){
	Kanan(*A1) = *A2;
	Kiri(*A2) = *A1;
}
// Menyambungkan A1 dengan A2 secara horizontal, Kanan(A1) menjadi A2 dan Kiri(A2) menjadi A1
void SambungVertikal(Area *A1,Area *A2){
	Atas(*A1) = *A2;
	Bawah(*A2) = *A1;
}
// Menyambungkan A1 dengan A2 secara Vertikal, Atas(A1) menjadi A2 dan Bawah(A2) menjadi A1

/* Pindah Area */
void PindahAtas(Position *Pos, Area *A){
	*A = Atas(*A);	
	PositionP(*Pos) = StartBawah(*A);
	AreaIDP(*Pos) = AreaID(*A);
}
//Berpindah ke Atas(A). Pos sekarang berpindah ke start bawah dari Atas(A). A menjadi Atas(A)
void PindahBawah(Position *Pos, Area *A){
	*A = Bawah(*A);	
	PositionP(*Pos) = StartAtas(*A);
	AreaIDP(*Pos) = AreaID(*A);
}
//Berpindah ke Bawah(A). Pos sekarang berpindah ke start atas dari Bawah(A). A menjadi Bawah(A)
void PindahKanan(Position *Pos, Area *A){
	*A = Kanan(*A);	
	PositionP(*Pos) = StartKiri(*A);
	AreaIDP(*Pos) = AreaID(*A);
}
//Berpindah ke Kanan(A). Pos sekarang berpindah ke start kiri dari Kanan(A). A menjadi Kanan(A)
void PindahKiri(Position *Pos, Area *A){
	*A = Kiri(*A);	
	PositionP(*Pos) = StartKanan(*A);
	AreaIDP(*Pos) = AreaID(*A);
}
//Berpindah ke Kiri(A). Pos sekarang berpindah ke start kanan dari Kiri(A). A menjadi Kiri(A)

/* Pindah Posisi */
void GoUp(Position *Pos, Area *A){
	int x = Absis(PositionP(*Pos));
	int y = Ordinat(PositionP(*Pos)) -1;
	if (EQ(StartAtas(*A),PositionP(*Pos))){
		PindahAtas(Pos,A);
	}
	else if (ElmtA(*A,x,y) == '#'){
		printf("You cannot go there\n");
	}
	else{
		Ordinat(PositionP(*Pos)) = y;
	}
}
//Berpindah ke petak Atas
void GoDown(Position *Pos, Area *A){
	int x = Absis(PositionP(*Pos));
	int y = Ordinat(PositionP(*Pos)) +1;
	if (EQ(StartBawah(*A),PositionP(*Pos))){
		PindahBawah(Pos, A);
	}
	else if (ElmtA(*A,x,y) == '#'){
		printf("You cannot go there\n");
	}
	else{
		Ordinat(PositionP(*Pos)) = y;
	}
}
//Berpindah ke petak bawah
void GoLeft(Position *Pos, Area *A){
	int x = Absis(PositionP(*Pos)) -1;
	int y = Ordinat(PositionP(*Pos));
	if (EQ(StartKiri(*A),PositionP(*Pos))){
		PindahKiri(Pos, A);
	}
	else if (ElmtA(*A,x,y) == '#'){
		printf("You cannot go there\n");
	}
	else{
		Absis(PositionP(*Pos)) = x;
	}	
}
//Berpindah ke petak kiri
void GoRight(Position *Pos, Area *A){
	int x = Absis(PositionP(*Pos))+1;
	int y = Ordinat(PositionP(*Pos));
	if (EQ(StartKanan(*A),PositionP(*Pos))){
		PindahKanan(Pos, A);
	}
	else if (ElmtA(*A,x,y) == '#'){
		printf("You cannot go there\n");
	}
	else{
		Absis(PositionP(*Pos)) = x;
	}		
}
//Berpindah ke petak kanan

/* Dan Lain Lain */
boolean isHealth(Position Pos, Area A){
	int x = Absis(Pos.CPos);
	int y = Ordinat(Pos.CPos);
	return (ElmtA(A,x,y) == 'H');
}
//Mengecek apakah Posisi sekarang adalah tempat health
boolean isEnemy(Position Pos, Area A){
	int x = Absis(Pos.CPos);
	int y = Ordinat(Pos.CPos);
	return (ElmtA(A,x,y) == 'H');
}
//Mengecek apakah posisi sekarang adalah tempat musuh
boolean isWall(Position Pos, Area A){
	int x = Absis(Pos.CPos);
	int y = Ordinat(Pos.CPos);
	return (ElmtA(A,x,y) == 'H');
}
//Mengecek apakah posisi sekarang adalah tempat yang tidak bisa dijalani (#)

int main(){
	int i;
	int j;
	Area A;
	address Posisi;
	CreateAreaEmpty(&A);
	AreaID(A)='1';
	for (i=1;i<=11;i++){
		for(j=1;j<=11;j++){
			ElmtA(A,i,j) = '#' ;
		}
	}
	Area A2;
	CreateAreaEmpty(&A2);
	for (i=1;i<=11;i++){
		for(j=1;j<=11;j++){
			ElmtA(A2,i,j) = '#' ;
		}
	}
	AreaID(A2)='2';
	SambungVertikal(&A,&A2);
	ElmtA(A,1,6) = '-';
	ElmtA(A2,11,4) = '-';
	Position X;
	PositionP(X) = MakePOINT(1,6);
	AreaIDP(X) = AreaID(A);
	Posisi = A;
	GoUp(&X,&Posisi);
	TulisPOINT(PositionP(X));
	printf("%c ",AreaIDP(X));
}
