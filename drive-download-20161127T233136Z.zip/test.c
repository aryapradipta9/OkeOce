#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "addadt.h"
#include "tree.h"
#include "stacklist.h"
#include "queuelist.h"
#include "interface.h"

// library warna
#define RED   "\x1B[31m"
#define GRN   "\x1B[32m"
#define YEL   "\x1B[33m"
#define BLU   "\x1B[34m"
#define MAG   "\x1B[35m"
#define CYN   "\x1B[36m"
#define WHT   "\x1B[37m"
#define RESET "\x1B[0m"

#define gotoxy(x,y) printf("\033[%d;%dH", (x), (y))
#define clearScreen() printf("\033[H\033[J")
#define clearRow() printf("\33[2K")

float DmgRed = 0;

// variabel global
char TabAksi[4];
boolean NullHP = false; // hp player habis
boolean menang = false; // hp musuh habis
Player P;
Enemy E;
Queue EnemyQ, EnemyQ1, EnemyQ2, PlayerQ;;
Stack EnemyStack;
int Ronde, counter;
BinTree T;
boolean DirDamage, AbsDamage;

const float CapDev = 100;


// definisi prosedur
void DisplaySetAksi(int X);


//main program
void main (){

  // kamus lokal
  char AksiPlayer, AksiEnemy, X;
  float DmgToPlayer, DmgToEnemy;
  int i, j;

  clearScreen();
  MakeTree(&T);
  gotoxy(1,1);
  //buat testing stack
  CreateEmpty(&EnemyStack);
  CreateEmptyQueue(&EnemyQ1);
  AddQueue(&EnemyQ1,'A');
  AddQueue(&EnemyQ1,'B');
  AddQueue(&EnemyQ1,'F');
  AddQueue(&EnemyQ1,'A');
  Push(&EnemyStack,EnemyQ1);
  CreateEmptyQueue(&EnemyQ2);
  AddQueue(&EnemyQ2,'F');
  AddQueue(&EnemyQ2,'B');
  AddQueue(&EnemyQ2,'A');
  AddQueue(&EnemyQ2,'B');
  Push(&EnemyStack,EnemyQ2);

  // dummy stats
  CopyString(P.Nama,"Encang Iskandar");
  P.LVL = 5;
  P.HP = 100;
  P.STR = 50;
  /*  jika base stats dari pembuatan karakter baru adalah 50/10/10
      dan jika setiap naik level akan meningkat sebesar 3 points
      dan dapat dialokasikan ke attack maupun defence.
  */
  P.DEF = 40;
  P.EXP = 0;
  P.NextLVL = 100;
  Ronde = 9;
  CopyString(E.Nama,"Tampan dan Berani");
  E.HP = 100;
  E.STR = 30;
  E.DEF = 20;
  int PUsed = 0;
  int UUsed = 0;
  int RUsed = 0;
  int YUsed = 0;

  // print frame awal
  battle_interface(E, Ronde);
  if (Akar(Left(T)).taken)
  {
    P.STR = P.STR + 10; // dummy
  }
  if (Akar(Right(T)).taken)
  {
    P.DEF = P.DEF + 10; // dummy
  }
  if (IsInstaKill(T))
  {
    for(j=7; j<=13; j++)
    {
      gotoxy(j,1);
      clearRow();
      gotoxy(j,1);
      printf(CYN"║                                                                                 ║\n"RESET);
    }
    gotoxy(10,20);
    AniPrintConst(P.Nama);
    AniPrintConst(" instantly kill " );
    AniPrint(E.Nama);
    menang = true;
  }

  while((Ronde <= 10) && (!NullHP) && (!menang))
  {
    clearScreen();
    gotoxy(1,1);
    battle_interface(E, Ronde);
    Pop(&EnemyStack,&EnemyQ);
    //entry array
    for (i = 0; i <= 3; i++)
    {
      DelQueue(&EnemyQ,&X);
      TabAksi[i] = X;
      //tulis kembali
      AddQueue(&EnemyQ,X);
    }
    //generate seed;
    srand(time(NULL));
    gotoxy(4,38);
    printf("Command : ");
    DisplaySetAksi((rand()) % 6);

    // baca stats
    int PDef = P.DEF;
    int DmgAdded = 0;
    boolean DoubleDamage = false;
    boolean ReturnDamage = false;
    // KalkulasiDamage
    if (IsDamageReceived(T))
    {
      DmgRed = 10; // nanti diganti
    }
    DmgToPlayer = (1 - (PDef/ CapDev)) * E.STR - DmgRed;
    DmgToEnemy = (1 - (E.DEF / CapDev)) * P.STR + DmgAdded;
    counter = 0;

    gotoxy(20,28);
    printf("_ _ _ _");
    // penulisan command dan available list
    gotoxy(6,3);
    printf("%s Attacked!",E.Nama);
    gotoxy(7,3);
    printf("List of active skill available :");
    j = 8;
    // bagian Damage Up;
    if ((Akar(Right(Left(T))).taken) && (PUsed < 1))
    {
      gotoxy(j,3);
      printf("%c (%s)",Akar(Right(Left(T))).cc, Akar(Right(Left(T))).description);
      j++;
    }
    // bagian Damage x2
    if ((Akar(Left(Right(Left(T)))).taken) && (UUsed < 1))
    {
      gotoxy(j,3);
      printf("%c (%s)",Akar(Left(Right(Left(T)))).cc, Akar(Left(Right(Left(T)))).description);
      j++;
    }
    // bagian Defence Up
    if ((Akar(Right(Right(T))).taken) && (RUsed < 1))
    {
      gotoxy(j,3);
      printf("%c (%s)",Akar(Right(Right(T))).cc, Akar(Right(Right(T))).description);
      j++;
    }
    // bagian Return 100% damage
    if ((Akar(Left(Right(Right(T)))).taken) && (YUsed < 1))
    {
      gotoxy(j,3);
      printf("%c (%s)",Akar(Left(Right(Right(T)))).cc, Akar(Left(Right(Right(T)))).description);
      j++;
    }
    // bagian hp-x, deal direct damage
    if (Akar(Right(Right(Right(T)))).taken)
    {
      gotoxy(j,3);
      printf("%c (%s)",Akar(Right(Right(Right(T)))).cc, Akar(Right(Right(Right(T)))).description);
      DirDamage = true;
      j++;
    }
    // bagian hp-x, absolute damage
    if (Akar(Right(Right(Left(T)))).taken)
    {
      gotoxy(j,3);
      printf("%c (%s)",Akar(Right(Right(Left(T)))).cc, Akar(Right(Right(Left(T)))).description);
      AbsDamage = true;
      j++;
    }

    gotoxy((j+2),3);
    printf("Please input your command");
    //mulai inserting Commands

    char ctemp, cc;
    int counter;
    CreateEmptyQueue(&PlayerQ);
    counter = 0;
    while(counter < 4)
    {
      gotoxy(22,1); // delete baris 17
      clearRow();
      printf(CYN "║                       ║                                                         ║\n"RESET);
      gotoxy(22,3);
      printf("Command :");
      gotoxy(22,28);
      scanf(" %c",&cc);
      if ((cc == 'A') || (cc == 'B') || (cc == 'F'))
      {
        AddQueue(&PlayerQ,cc);
        counter = counter + 1;
        gotoxy(20,((2 * counter) + 26));
        printf("%c",cc);
      }
      else if (cc == 'E')
      {
        while (!IsEmptyQueue(PlayerQ))
        {
          DelQueue(&PlayerQ,&ctemp);
        }
        gotoxy(20,28);
        printf("_ _ _ _");
        counter = 0;
      }
      else if ((cc == 'P') && (PUsed < 1))
      {
        // damage added
        DmgAdded = 10; //tambahkan 10 damage dalam 1 turn
        PUsed++;
      }
      else if ((cc == 'R') && (RUsed < 1))
      {
        PDef = P.DEF * 2; // damage x2
        RUsed++;
      }
      else if ((cc == 'U') && (UUsed < 1))
      {
        DoubleDamage = true;
        UUsed++;
      }
      else if ((cc == 'Y') && (YUsed < 1))
      {
        ReturnDamage = true;
        YUsed++;
      }
      else if ((DirDamage) && (cc == 'Z'))
      {
        E.HP = E.HP - DmgToEnemy;
        P.HP = P.HP - 40;
      }
      else if ((AbsDamage) && (cc == 'V'))
      {
        DmgToEnemy = 1 * P.STR + DmgAdded;
      }
    }

    // hilangkan frame Command
    gotoxy(21,1);
    printf(CYN "╚═══════════════════════╩═════════════════════════════════════════════════════════╝\n" RESET);
    clearRow();// delete row 17
    printf("\n");
    clearRow(); // delete row 18
    for(j=7; j<=13; j++)
    {
      gotoxy(j,1);
      clearRow();
      gotoxy(j,1);
      printf(CYN"║                                                                                 ║\n"RESET);
    }
    // kalkulasi Damage
    /*  sistem damage
        (1-(Def / CapDev)) * Str - DmgReduction.
        CapLevel = 10
        CapDev = 100;
    */
    counter = 0;
    // kalkulasi damage

    // display panah dan pilihan
    gotoxy(4,48);
    printf(">%c",TabAksi[0]);
    gotoxy(20,27);
    printf(">");
    char cdummy;
    while ((!NullHP) && (!menang) && (counter < 4))
    {
      counter++;
      gotoxy(22,counter);
      DelQueue(&PlayerQ,&AksiPlayer);
      DelQueue(&EnemyQ,&AksiEnemy);
      printf(" ");
      if (IsTripleKill(T))
      {
        DmgToEnemy = DmgToEnemy * 3;
      }
      else if (IsDoubeKill(T))
      {
        DmgToEnemy = DmgToEnemy * 2;
      }

      if (DoubleDamage)
      {
        DmgToPlayer = DmgToPlayer * 2;
        DmgToEnemy = DmgToEnemy * 2;
      }
      gotoxy(counter + 6,3);
      if ((AksiPlayer == 'A') || (AksiEnemy == 'A'))
      {
        if ((AksiPlayer == 'A') && (AksiEnemy == 'A'))
        {
          printf("%s and %s attack each other",P.Nama,E.Nama);
        }
        else if (AksiPlayer == 'A')
        {
          if (AksiEnemy == 'B')
          {
            printf("%s attacks %s, but it's blocked!",P.Nama, E.Nama);
          }
          else
          {
            E.HP = E.HP - DmgToEnemy;
            printf("%s attacks %s! %s -%.0f",P.Nama, E.Nama, E.Nama, DmgToEnemy);
          }
        }
        else if (AksiEnemy == 'A')
        {
          if (AksiPlayer == 'B')
          {
            printf("%s attacks %s, but it's blocked!",E.Nama, P.Nama);
            if (Akar(Right(Left(Left(T)))).taken)
            {
              E.HP = E.HP - (0.05 * DmgToEnemy);
              printf("%s used block skill, enemy take %.0f damage",E.Nama,(0.05 * DmgToEnemy));
            }
          }
          else
          {
            if (ReturnDamage)
            {
              printf("%s use Return Damage! %s -%.0f", P.Nama, E.Nama, DmgToPlayer);
              E.HP = E.HP - DmgToPlayer;
            }
            else
            {
              P.HP = P.HP - DmgToPlayer;
              printf("%s attacks %s! %s -%.0f",E.Nama, P.Nama, P.Nama, DmgToPlayer);
            }
          }
        }
      }
      else if ((AksiPlayer == 'B') || (AksiEnemy == 'B'))
      {
        if ((AksiPlayer == 'B') && (AksiEnemy == 'B'))
        {
          printf("%s and %s blocks each other",P.Nama,E.Nama);
        }
        else if (AksiPlayer == 'B')
        {
          if (ReturnDamage)
          {
            printf("%s use Return Damage! %s -%.0f",P.Nama, E.Nama, DmgToPlayer);
            E.HP = E.HP - DmgToPlayer;
          }
          else
          {
            P.HP = P.HP - DmgToPlayer;
            printf("%s flanks %s! %s -%.0f",E.Nama, P.Nama, P.Nama, DmgToPlayer);
          }
        }
        else if (AksiEnemy == 'B')
        {
          E.HP = E.HP - DmgToEnemy;
          printf("%s flanks %s! %s -%.0f",P.Nama, E.Nama, E.Nama, DmgToEnemy);
        }
      }
      else //both flanks
      {
        printf("%s and %s flanks each other",P.Nama,E.Nama);
      }
      //UpdateStats();
      if (P.HP == 0)
      {
        NullHP = true;
      }
      else if (E.HP == 0)
      {
        menang = true;
      }
      fflush(stdout);
      usleep(1000000);
      gotoxy(4,48 + (counter * 2));
      printf(">%c",TabAksi[counter]);
      gotoxy(4,46 + (counter * 2));
      printf(" ");
      gotoxy(20,27 + (counter * 2));
      printf(">");
      gotoxy(20,25 + (counter * 2));
      printf(" ");
      gotoxy(24,counter);

    }
    if ((!NullHP) && (!menang)) // musuh belum kalah dan hp player belum habis
    {
      Ronde++;
    }
  }
}

void DisplaySetAksi(int X)
{
  switch (X)
  {
    case 0 :
    {
      printf(" # # %c %c",TabAksi[2],TabAksi[3]);
      break;
    }
    case 1 :
    {
      printf(" # %c # %c",TabAksi[1],TabAksi[3]);
      break;
    }
    case 2 :
    {
      printf(" # %c %c #",TabAksi[1],TabAksi[2]);
      break;
    }
    case 3 :
    {
      printf(" %c # # %c",TabAksi[0],TabAksi[3]);
      break;
    }
    case 4 :
    {
      printf(" %c # %c #",TabAksi[0],TabAksi[2]);
      break;
    }
    case 5 :
    {
      printf(" %c %c # #",TabAksi[0],TabAksi[1]);
      break;
    }
  }
}
