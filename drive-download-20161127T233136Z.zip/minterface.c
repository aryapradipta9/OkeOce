#include "interface.h"
#include "addadt.h"
#include "tree.h"

int main()
{
  // test main_menu
  main_menu();

  // test enemyloading
  enemyloading();

  // test loading_screen
  loading_screen();

  // test credits
  int i = credits();

  // test mapinterface
  mapinterface(30);

  // entry data contoh
  Player P;
  CopyString(P.Nama,"Lalala");
  P.LVL = 5;
  P.HP = 100;
  P.STR = 50;
  P.DEF = 40;
  P.EXP = 0;
  P.NextLVL = 100;
  BinTree T;
  MakeTree(&T);
  Area A;
  CreateAreaEmpty(&A);
  Enemy E;
  CopyString(E.Nama,"Tampan dan Berani");
  E.HP = 100;
  E.STR = 30;
  E.DEF = 20;

  // test treebuilder
  i = treebuilder(&T);

  // test mapdraw
  mapdraw(A);

  // test battle_interface
  battle_interface(E,5);

  // test level_up
  level_up(&P,&T);

  //test PrintTree
  PrintTree(T);

  return 0;
}
