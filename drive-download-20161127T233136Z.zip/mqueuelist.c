#include "queuelist.h"
#include <stdio.h>

int main ()
{
Queue EnemyQ1;
CreateEmptyQueue(&EnemyQ1);
AddQueue(&EnemyQ1,'A');
AddQueue(&EnemyQ1,'B');
AddQueue(&EnemyQ1,'F');
AddQueue(&EnemyQ1,'A');
char cc;
DelQueue(&EnemyQ1,&cc);

printf("%d",NbElmtQueue(EnemyQ1));
printf("%d",IsEmptyQueue(EnemyQ1));
return 0;
}
