#include "queuelist.h"
#include "stacklist.h"


int main ()
{
  Stack EnemyStack;
  Queue EnemyQ1, EnemyQ2;
CreateEmpty(&EnemyStack);
CreateEmptyQueue(&EnemyQ1);
AddQueue(&EnemyQ1,'A');
AddQueue(&EnemyQ1,'B');
AddQueue(&EnemyQ1,'F');
AddQueue(&EnemyQ1,'A');
Push(&EnemyStack,EnemyQ1);
CreateEmptyQueue(&EnemyQ2);
AddQueue(&EnemyQ2,'F');
AddQueue(&EnemyQ2,'B');
AddQueue(&EnemyQ2,'A');
AddQueue(&EnemyQ2,'B');
Push(&EnemyStack,EnemyQ2);
return 0;
}
