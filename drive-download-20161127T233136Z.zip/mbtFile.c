/** File Name 	: mbtFile.c
  * Author		: Jasman Pardede
  * NIM			: 33216013
  * Tanggal		: 13 September 2016
  * Deskripsi	: Membuat ADT Baca dan Tulis File
  */
  
  #include "bacatulisFile.h"
  
// #define MAX_STRING_LENGTH 1000
// #define MAX_STRING_LENGTH_FILE 50

char s[MAX_STRING_LENGTH];
char file[MAX_FIlE_NAME_LENGTH];
char path[MAX_STRING_PATH];	
char r[MAX_STRING_LENGTH];

FILE *p;
int sum, i;

int main(){
  
  	printf("Masukkan nama file : ");
	gets(file);
	printf("File exits : %d", isFileNameValid(file));	// cek file pada direktori based dimana main program dijalankan
	printf("\n");
	printf(":: Proses cek nama file berdasarkan path dan nama file ::");
	printf("\n");
	printf("Masukkan nama path : ");
	printf("\n");
	gets(path);
	printf("File based path exist : %d", fileExists(path, file)); 	// cek file pada direktori based path yang diberikan
	printf("\n");
	
	// baca isi file
	if(isFileNameValid(file)){
		getContentFile(file, r);
	}
	printf("File yang dibaca : \n");
	printf("%s", r);
	printf("\n");
	// menyimpan data ke file tertentu
//	printf("\n");
//	printf("Masukkan nama file : ");	
//	gets(file);
//	printf("File %s, sudah dihapus : %d", file, removeFile(file));
	
	printf("Penggunaan menyimpan content kedalam file : ");
	printf("\n");
	printf("Masukkan nama file : ");
	printf("\n");
	gets(file);
	printf("Masukkan konten yang hendak disimpan : ");
	gets(s);
	saveContentFile(file,s);

	
	printf("\n");
	
  	return 0;
}
