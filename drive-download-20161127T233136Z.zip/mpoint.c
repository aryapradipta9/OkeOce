#include "point.h"
int main(){
	x = 3;
	y = 4;
	Point Y;
	Y = MakePOINT(x,y);
	printf("<%d,%d>",Absis(Y),Ordinat(Y));
	return 0;
}