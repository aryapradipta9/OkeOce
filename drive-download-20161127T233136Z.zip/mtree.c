#include "tree.h"
#include "addadt.h"
#include <stdio.h>

int main ()
{
  // test alokasi
  addressTree P;
  BinTree PTree;
  infoTree X;
  X.cc = 'L';
  X.taken = true;
  CopyString(X.description,"unlock skill");
  AlokasiTree (&P,X);
  MakeTree(&PTree);

  // test BinTree
  BinTree T7, T8, T3;
  X.PosX = 0;
  X.PosY = 0;
  //entry 7
  X.cc = 'S';
  X.taken = false;
  CopyString(X.description, "10 percent chance to triple attack"); //done
  AlokasiTree(&T7,X);
  // entry 8
  X.cc = 'T';
  X.taken = false;
  CopyString(X.description, "1 percent to instant kill"); //done
  AlokasiTree(&T8,X);
  // entry 3
  X.cc = 'O';
  X.taken = false;
  CopyString(X.description, "30 percent chance to double attack"); //done
  T3 = Tree(X,&T7,&T8);


  printf("%d",IsDoubeKill(PTree));

printf("%d",IsTripleKill(PTree));

printf("%d",IsInstaKill(PTree));

printf("%d",IsDamageReceived(PTree));
boolean found;
  SetTreeTaken (&PTree,'L',&found);

  DealokasiTree(T3);
  return 0;
}
