#include "area.h"
#include <stdio.h>

int main(){
	address current;
	Position pos;
	int i;
	int j;
	Area A1;
	Area A2;
	Area A3;
	CreateAreaEmpty(&A1);
	CreateAreaEmpty(&A2);
	CreateAreaEmpty(&A3);
	AreaID(A1)='1';
	AreaID(A2)='2';
	AreaID(A3)='3';
	for(i=1;i<=11;i++){
		for(j=1;j<=11;j++){
			if ((i==6)||(j==6)){
				ElmtA(A1,i,j) = '-';
			}
			else
				ElmtA(A1,i,j) = '#';
		}
	}
	for(i=1;i<=11;i++){
		for(j=1;j<=11;j++){
			if (i==6){
				ElmtA(A2,i,j) = '-';
			}
			else
				ElmtA(A2,i,j) = '#';
		}
	}
	for(i=1;i<=11;i++){
		for(j=1;j<=11;j++){
			if (j==6){
				ElmtA(A3,i,j) = '-';
			}
			else
				ElmtA(A3,i,j) = '#';
		}
	}
	PositionP(pos) = MakePOINT(6,6);
	AreaIDP(pos) = AreaID(A1);
	SambungVertikal(&A1,&A3);
	SambungHorizontal(&A1,&A2);
	current = A1;
	int a = 5;
	while(a != 0){
		for(i=1;i<=11;i++){
			for(j=1;j<=11;j++){
				if ((i==Absis(PositionP(pos)))&&(j==Ordinat(PositionP(pos))))
					printf("P ");
				else
					printf("%c ",ElmtA(current,i,j));
			}
		printf("\n");
		}
		scanf("%d",&a);
		if (a==1){
			GoUp(&pos,&current);
		}
		else if (a==2)
			GoDown(&pos,&current);
		else if (a==3)
			GoLeft(&pos,&current);
		else if (a==4)
			GoRight(&pos,&current);
	}
}