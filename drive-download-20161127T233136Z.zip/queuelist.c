#include "queuelist.h"
#include "boolean.h"
#include <stdlib.h>

/* Prototype manajemen memori */
void AlokasiQueue (addressQueue *P, infotypeQueue X)
/* I.S. Sembarang */
/* F.S. Alamat P dialokasi, jika berhasil maka Info(P)=X dan
        Next(P)=Nil */
/*      P=Nil jika alokasi gagal */
{
        *P = (addressQueue) malloc (sizeof (ElmtQueue));
        Info(*P) = X;
        Next(*P) = Nil;
}
void DealokasiQueue (addressQueue  P)
/* I.S. P adalah hasil alokasi, P != Nil */
/* F.S. Alamat P didealokasi, dikembalikan ke sistem */
{
	free(P);
}
boolean IsEmptyQueue (Queue Q)
/* Mengirim true jika Q kosong: HEAD(Q)=Nil and TAIL(Q)=Nil */
{
	return((Head(Q) == Nil) && (Tail(Q) == Nil));
}
int NbElmtQueue(Queue Q)
/* Mengirimkan banyaknya elemen queue. Mengirimkan 0 jika Q kosong */
{
        int count;
        addressQueue P;
        count = 0;
        P = Head(Q);
        while (P != Nil)
        {
                count = count + 1;
                P = Next(P);
        }
        return count;
}

/*** Kreator ***/
void CreateEmptyQueue(Queue * Q)
/* I.S. sembarang */
/* F.S. Sebuah Q kosong terbentuk */
{
    Head(*Q) = Nil;
    Tail(*Q) = Nil;
}
/*** Primitif AddQueue/DelQueueeteQueue ***/
void AddQueue (Queue * Q, infotypeQueue X)
/* Proses: Mengalokasi X dan menambahkan X pada bagian TAIL dari Q
   jika alokasi berhasil; jika alokasi gagal Q tetap */
/* Pada dasarnya adalah proses insert last */
/* I.S. Q mungkin kosong */
/* F.S. X menjadi TAIL, TAIL "maju" */
{
	addressQueue P;
    AlokasiQueue(&P,X);
    if (P != Nil)
    {
        if (IsEmptyQueue(*Q))
        {
        	Next(P) = Head(*Q);
        	Head(*Q) = P;
        	Tail(*Q) = P;
        }
        else
        {
        	Next(Tail(*Q)) = P;
        	Tail(*Q) = P;
        	Next(P) = Nil;
        }
    }
}
void DelQueue(Queue * Q, infotypeQueue * X)
/* Proses: Menghapus X pada bagian HEAD dari Q dan mendealokasi
   elemen HEAD */
/* Pada dasarnya operasi delete first */
/* I.S. Q tidak mungkin kosong */
/* F.S. X = nilai elemen HEAD pd I.S., HEAD "mundur" */
{
    addressQueue P;
    *X = InfoHead(*Q);
    P = Head(*Q);
    Head(*Q) = Next(Head(*Q));
    if (Head(*Q) == Nil)
    {
    	Tail(*Q) = Nil;
    }
    DealokasiQueue(P);
}
