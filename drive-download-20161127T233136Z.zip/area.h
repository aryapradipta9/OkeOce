#ifndef AREA_H
#define AREA_H

#include "point.h"
#include "matriks.h"
#include <stdlib.h>
#include "boolean.h"

#define Nil NULL


typedef struct tArea *address;
typedef struct tArea{
	MATRIKS A;
	char ID;
	address Atas;
	address Bawah;
	address Kanan;
	address Kiri;
} AreaNode;

typedef address Area;
#define Kiri(aArea) (aArea)->Kiri
#define Kanan(aArea) (aArea)->Kanan
#define Atas(aArea) (aArea)->Atas
#define Bawah(aArea) (aArea)->Bawah
#define AreaID(aArea) (aArea)->ID
#define ElmtA(MA,i,j) Elmt(((MA)->A),i,j)
#define MatriksA(aArea) (aArea)->A

typedef struct {
	POINT CPos;
	char CAreaID;
} Position;

#define PositionP(P) (P).CPos
#define AreaIDP(P) (P).CAreaID

void CreateAreaEmpty(Area *A);
//Mengalokasi Area di memori
void Dealokasi(Area A);
/* Menyambungkan Area */
//Mencari Titit Start
POINT StartAtas(Area A);
POINT StartBawah(Area A);
POINT StartKanan(Area A);
POINT StartKiri (Area A);

void SambungHorizontal(Area *A1,Area *A2);
// Menyambungkan A1 dengan A2 secara horizontal, Kanan(A1) menjadi A2 dan Kiri(A2) menjadi A1
void SambungVertikal(Area *A1,Area *A2);
// Menyambungkan A1 dengan A2 secara Vertikal, Atas(A1) menjadi A2 dan Bawah(A2) menjadi A1

/* Pindah Area */
void PindahAtas(Position *Pos, Area *A);
//Berpindah ke Atas(A). Pos sekarang berpindah ke start bawah dari Atas(A). A menjadi Atas(A)
void PindahBawah(Position *Pos, Area *A);
//Berpindah ke Bawah(A). Pos sekarang berpindah ke start atas dari Bawah(A). A menjadi Bawah(A)
void PindahKanan(Position *Pos, Area *A);
//Berpindah ke Kanan(A). Pos sekarang berpindah ke start kiri dari Kanan(A). A menjadi Kanan(A)
void PindahKiri(Position *Pos, Area *A);
//Berpindah ke Kiri(A). Pos sekarang berpindah ke start kanan dari Kiri(A). A menjadi Kiri(A)


/* Pindah Posisi */
void GoUp(Position *Pos, Area *A);
//Berpindah ke petak Atas
void GoDown(Position *Pos, Area *A);
//Berpindah ke petak bawah
void GoLeft(Position *Pos, Area *A);
//Berpindah ke peta kiri
void GoRight(Position *Pos, Area *A);
//Berpindah ke peta kanan

/* Dan Lain Lain */
boolean isHealth(Position Pos, Area A);
//Mengecek apakah Posisi sekarang adalah tempat health
boolean isEnemy(Position Pos, Area A);
//Mengecek apakah posisi sekarang adalah tempat musuh
boolean isWall(Position Pos, Area A);
//Mengecek apakah posisi sekarang adalah tempat yang tidak bisa dijalani (#)
#endif