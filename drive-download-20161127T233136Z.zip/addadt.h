#ifndef _ADDADT_H_
#define _ADDADT_H_

/* addadt ini merupakan fungsi fungsi yang sering dipakai dalam program ini */

int getch(void);
/* menghasilkan kode ascii dari karakter yang diinputkan */

char ArrowPressed();
/* konversi getch ke char */

void CopyString(char dest[], const char source[]);
/* ekuivalen strcpy pada string.h */

void AniPrint(char src[]);
/* membuat teks animasi seperti typewriter. Sumber teks adalah variabel */

void AniPrintConst(const char src[]);
/* membuat teks animasi seperti typewriter. Sumber teks adalah konstanta */

#endif
