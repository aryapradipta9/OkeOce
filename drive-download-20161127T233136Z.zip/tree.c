/* NIM/Nama : 13515017 / Putu Arya Pradipta */
/* Kelompok : 9 */
/* Deskripsi: Implementasi ADT tree (tree.c) */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "boolean.h"
#include "tree.h"
#include "addadt.h"

/* Definisi PohonBiner : */
/* Pohon Biner kosong : P = Nil */
typedef addressTree BinTree;

void AlokasiTree (addressTree *P, infoTree X)
{
  *P = (addressTree) malloc (sizeof(Node));
  Akar(*P) = X;
  Left(*P) = Nil;
  Right(*P) = Nil;
  Parent(*P) = Nil;
}

BinTree Tree (infoTree Akar, BinTree *L, BinTree *R)
{
  addressTree P;
  AlokasiTree(&P,Akar);
  Left(P) = *L;
  Right(P) = *R;
  Parent(*L) = P;
  Parent(*R) = P;
  return P;
}

void DealokasiTree (addressTree  P)
/* I.S. P adalah hasil alokasi, P != Nil */
/* F.S. Alamat P didealokasi, dikembalikan ke sistem */
{
	free(P);
}

boolean IsDoubeKill (BinTree T)
{
  if (Akar(Left(Left(T))).taken)
  {
    srand(time(NULL));
    if (((rand()) % 100) < 30)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
  else
  {
    return false;
  }
}

void MakeTree(BinTree *T)
{
  BinTree T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14;
  infoTree X;
  X.PosX = 0;
  X.PosY = 0;
  //entry 7
  X.cc = 'S';
  X.taken = false;
  CopyString(X.description, "10 percent chance to triple attack"); //done
  AlokasiTree(&T7,X);
  // entry 8
  X.cc = 'T';
  X.taken = false;
  CopyString(X.description, "1 percent to instant kill"); //done
  AlokasiTree(&T8,X);
  // entry 3
  X.cc = 'O';
  X.taken = false;
  CopyString(X.description, "30 percent chance to double attack"); //done
  T3 = Tree(X,&T7,&T8);
  // entry 9
  X.cc = 'U';
  X.taken = true;
  CopyString(X.description, "Damage x2, Receive Damage x2 (only for 1 turn)"); //done, aktif
  AlokasiTree(&T9,X);
  // entry 10
  X.cc = 'V';
  X.taken = true;
  CopyString(X.description, "Sacrifice xx HP for Absolute Damage"); // aktif
  AlokasiTree(&T10,X);
  // entry 4
  X.cc = 'P';
  X.taken = true; // test
  CopyString(X.description, "Damage + xx for 1 turn"); //aktif, udah
  T4 = Tree(X,&T9,&T10);
  // entry 11
  X.cc = 'W';
  X.taken = false;
  CopyString(X.description, "5 percent damage caused while block attacks"); // pasif, done
  AlokasiTree(&T11,X);
  // entry 12
  X.cc = 'X';
  X.taken = false;
  CopyString(X.description, "Return 20 percent damage when using defense"); //done
  AlokasiTree(&T12,X);
  // entry 5
  X.cc = 'Q';
  X.taken = false;
  CopyString(X.description, "Damage received - x"); //done
  T5 = Tree(X,&T11,&T12);
  //entry 13
  X.cc = 'Y';
  X.taken = true; //test
  CopyString(X.description, "HP - x, return 100 percent damage this time"); //done
  AlokasiTree(&T13,X);
  // entry 14
  X.cc = 'Z';
  X.taken = true;
  CopyString(X.description, "HP - x, deal damage xx");// aktif, donne
  AlokasiTree(&T14,X);
  // entry 6
  X.cc = 'R';
  X.taken = true;
  CopyString(X.description, "Defence up 200 percent in 1 round"); //done, truue
  T6 = Tree(X,&T13,&T14);
  // entry 1
  X.cc = 'M';
  X.taken = false;
  CopyString(X.description, "Attack up xxx"); //done
  T1 = Tree(X,&T3,&T4);
  // entry 2
  X.cc = 'N';
  X.taken = false;
  CopyString(X.description, "Defense up xxx"); //done
  T2 = Tree(X,&T5,&T6);
  // entry 0;
  X.cc = 'L';
  X.taken = false;
  CopyString(X.description, "Unlock skill tree"); //done
  *T = Tree(X,&T1,&T2);
}

boolean IsTripleKill (BinTree T)
{
  if (Akar(Left(Left(Left(T)))).taken)
  {
    srand(time(NULL));
    if (((rand()) % 100) < 10)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
  else
  {
    return false;
  }
}

boolean IsInstaKill (BinTree T)
{
  if (Akar(Right(Left(Left(T)))).taken)
  {
    srand(time(NULL));
    if (((rand()) % 100) == 1)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
  else
  {
    return false;
  }
}

boolean IsDamageReceived (BinTree T)
{
  if (Akar(Left(Right(T))).taken)
  {
    return true;
  }
  else
  {
    return false;
  }
}

void SetTreeTaken (BinTree *T, char cc, boolean *found)
{
  if ((Left(*T) == Nil) && (Right(*T) == Nil))
  {
    *found = false;
  }
  else if (Akar(*T).cc == cc)
  {
    if (!Akar(*T).taken)
    {
      Akar(*T).taken = true;
      *found  = true;
    }
    else
    {
      *found = false;
    }
  }
  else
  {
    boolean f1,f2;
    SetTreeTaken(&Left(*T),cc,&f1);
    SetTreeTaken(&Right(*T),cc,&f2);
    *found = f1 || f2;
  }
}
