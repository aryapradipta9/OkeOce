/* File: point.c */
/* Tanggal: 31 Agustus 2016 */
/* *** Definisi ABSTRACT DATA TYPE POINT *** */
/* *** Notasi Akses: Selektor POINT *** */

#include "point.h"
#include <stdio.h>
        
/* *** DEFINISI PROTOTIPE PRIMITIF *** */
/* *** Konstruktor membentuk POINT *** */
POINT MakePOINT (int X, int Y){
	POINT P;
	Absis(P) = X;
	Ordinat(P) = Y;
	return P;
}
