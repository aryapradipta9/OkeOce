/** File Name 	: bacatulisFile.c
  * Author		: Jasman Pardede
  * NIM			: 33216013
  * Tanggal		: 13 September 2016
  * Deskripsi	: Membuat ADT Baca dan Tulis File
  */

#include "bacatulisFile.h"

FILE *p;
int c;
DIR *dp;
struct dirent *ep;

boolean isFileNameValid(char *fileName){
	FILE *fp = fopen (fileName, "r");
	if (fp!=NULL) 
		fclose (fp);
	return (fp!=NULL);	
}


boolean fileExists(const char *path, const char *base){
		
    int found = 0;
    size_t size = strlen(base); 
    if ( (dp = opendir (path)) != NULL) {
        while ( !found && (ep = readdir (dp)) ) {
             found = !strncmp(ep->d_name, base, size);
        }
        (void) closedir (dp);
    }
    else
            perror ("Couldn't open the directory");
    return found;
}

void saveContentFile(char *fileName, char *myContent){
	if(isFileNameValid(fileName)){
		p = fopen(fileName,"a");
		fprintf(p, " %s ", myContent);
	}
	else{
		p = fopen(fileName, "w+");
		fprintf(p, " %s ", myContent);		
	}
	fclose(p);	
}

void getContentFile(char *fileName, char *myContent){
	char tmpS[MAX_STRING_LENGTH];
	int i=0;
	p = fopen(fileName, "r");
	while(true){
		c = fgetc(p);
		if(!feof(p)){
			myContent[i]=c;
			i++;
		}
		else{
			break;
		}
	}
	fclose(p);
}

boolean removeFile(char *fileName){
	int rm;
	rm = remove(fileName);
	if(rm==0){
		return true;
	}
	else
		return false;
}
