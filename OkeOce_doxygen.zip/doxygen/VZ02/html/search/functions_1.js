var searchData=
[
  ['bear',['Bear',['../class_bear.html#a639d2d41ec84454055f7b44f23c39639',1,'Bear']]]
];
