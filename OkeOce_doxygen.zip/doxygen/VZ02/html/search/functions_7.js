var searchData=
[
  ['panda',['Panda',['../class_panda.html#a489fdb1f4fe88f0c0c99a3f0768212b4',1,'Panda']]],
  ['pari',['Pari',['../class_pari.html#a5a119732b193e06037a00456c6606c35',1,'Pari']]],
  ['penguin',['Penguin',['../class_penguin.html#a215ac88a9d57ac01355e414c0527e862',1,'Penguin']]]
];
