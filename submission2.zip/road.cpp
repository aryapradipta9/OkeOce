#include "road.h"

/** @brief jalan
  * @param posx posisi x
  *	@param posy posisi y
  */
Road::Road()
{}

/** @brief render nawn nawn
  * @param cc nawn nawn
  */
char Road::GetRender()
{
	return('-');
}