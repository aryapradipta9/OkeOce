#ifndef ROAD_H
#define ROAD_H
using namespace std;

class Road
{
public:
	/** @brief jalan
	  * @param posx posisi x
	  *	@param posy posisi y
	  */
	Road();

	/** @brief render nawn nawn
	  * @param cc nawn nawn
	  */
	char GetRender();
};
#endif