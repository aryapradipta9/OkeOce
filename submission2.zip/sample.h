class Sample {
  public:
    Sample();
    void Add (int x);
    void Min (int x);
    void Print ();
    int getVal();
  private:
    int v;
};

