#include "water_habitat.h"

/** @brief constructor
  * @param posx posisi x
  * @param posy posisi y
  */
WaterHabitat::WaterHabitat(){}//ctor
/**	@brief Destructor
  */
WaterHabitat::~WaterHabitat(){}//dtor
/**	@brief render nawn
  *	@param cc nawnnawn
  */
char WaterHabitat::GetRender()
{
	return('$');
}
